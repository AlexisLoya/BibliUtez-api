create definer = root@localhost trigger usuarios_AFTER_INSERT
    after insert
    on usuarios
    for each row
BEGIN
IF NEW.roles_id = 2 Then
	INSERT INTO `bibliutez`.`clientes` (`usuarios_id`) VALUES (NEW.id);
    INSERT INTO `bibliutez`.`carritos` (`usuarios_id`) VALUES (NEW.id);
else
	INSERT INTO `bibliutez`.`gerentes` (`usuarios_id`) VALUES (NEW.id);
     INSERT INTO `bibliutez`.`carritos` (`usuarios_id`) VALUES (NEW.id);
end if;

END;

